const countdownDate = new Date("October 27, 2024 17:00:00").getTime();

function updateCountdown() {
    const now = new Date().getTime();
    const distance = countdownDate - now;

    const weeks = Math.floor(distance / (1000 * 60 * 60 * 24 * 7));
    const days = Math.floor((distance % (1000 * 60 * 60 * 24 * 7)) / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.querySelectorAll('.unit p')[0].innerText = weeks;
    document.querySelectorAll('.unit p')[1].innerText = days;
    document.querySelectorAll('.unit p')[2].innerText = hours;
    document.querySelectorAll('.unit p')[3].innerText = minutes;
    document.querySelectorAll('.unit p')[4].innerText = seconds;

    if (distance < 0) {
        clearInterval(countdownInterval);
        document.getElementById("countdown").innerHTML = "Событие началось!";
    }
}

const countdownInterval = setInterval(updateCountdown, 1000);

const interval = setInterval(updateCountdown, 1000);


const audioPlayer = document.getElementById('audioPlayer');
const playPauseBtn = document.getElementById('playPauseBtn');

function togglePlayPause() {
    if (audioPlayer.paused) {
        audioPlayer.play();
        playPauseBtn.textContent = 'Pause';
    } else {
        audioPlayer.pause();
        playPauseBtn.textContent = 'Play';
    }
}
let text = document.querySelector('.text');
let containerWidth = document.querySelector('.container').offsetWidth;
let textWidth = text.offsetWidth;

let startPosition = containerWidth;

function moveText() {
  startPosition -= 1;  // Движение текста влево
  if (startPosition <= -textWidth) {
    startPosition = containerWidth;  // Если текст полностью вышел за левый край, возвращаем его в начало
  }
  text.style.transform = `translateX(${startPosition}px)`;

  requestAnimationFrame(moveText);  // Запускаем анимацию заново
}

moveText();

